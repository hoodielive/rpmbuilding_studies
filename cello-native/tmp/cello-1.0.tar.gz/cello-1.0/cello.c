#include <stdio.h>

int main(void)
{
	printf("Howdy, cello! Here is a patch.\n");
	return 0;
}
